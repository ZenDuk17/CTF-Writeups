#!/usr/bin/env bash
set -euo pipefail

HANDOUT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
QEMU_BIN=${QEMU_BIN:-qemu-system-aarch64}
GDB_STUB=${GDB_STUB:-1}

QEMU_ARGS=(
	-machine virt,dtb-randomness=on
	-cpu cortex-a57
	-smp 1
	-m 128M
	-nographic
	-nic none
	-monitor none
	-kernel "$HANDOUT_DIR/Image"
	-initrd "$HANDOUT_DIR/rootfs.cpio.gz"
	-dtb "$HANDOUT_DIR/qemu-virt-mali.dtb"
	-append "console=ttyAMA0 loglevel=3 page_alloc.shuffle=1 oops=panic panic=1"
	-no-reboot
)

if [[ "$GDB_STUB" != "0" ]]; then
	QEMU_ARGS+=(-s)
fi

exec timeout --foreground 60 "$QEMU_BIN" "${QEMU_ARGS[@]}"
