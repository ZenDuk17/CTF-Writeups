bin 文件夹下的 `Simulation_debug` 版本，可以在跑完你的指令后生成对应波形图文件 `sim.vcd`

`sim.sh` 是编译程序时的指令