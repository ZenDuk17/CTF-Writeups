#!/bin/sh
set -e

socat TCP-LISTEN:9999,reuseaddr,fork EXEC:/home/ctf/chall &
exec tail -f /dev/null
