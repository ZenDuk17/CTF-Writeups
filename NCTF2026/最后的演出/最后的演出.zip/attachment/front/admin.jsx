import React, { startTransition, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";

function AdminApp() {
  const [mounted, setMounted] = useState(false);
  const [status, setStatus] = useState("Checking session...");
  const [rewardText, setRewardText] = useState("Loading PIE...");
  const [pwnKey, setPwnKey] = useState("");
  const [pwnHint, setPwnHint] = useState("Ready to send.");
  const [downloadFile, setDownloadFile] = useState("");
  const [downloadHint, setDownloadHint] = useState("Enter a file name to request a protected download.");

  async function loadReward() {
    setRewardText("Loading PIE...");

    try {
      const response = await fetch("./reward", {
        method: "POST",
        headers: {
          "Content-Type": "text/plain;charset=UTF-8"
        },
        body: "Win"
      });

      const text = await response.text();
      startTransition(() => {
        setRewardText(response.ok ? text : `Reward request failed: ${text}`);
      });
    } catch (error) {
      setRewardText(`Reward request failed: ${error.message}`);
    }
  }

  useEffect(() => {
    setMounted(true);
    fetch("./session", { credentials: "same-origin" })
      .then(async (response) => {
        if (!response.ok) {
          throw new Error("Session missing");
        }
        const data = await response.json();
        setStatus(data.authenticated ? `Authorized session detected: ${data.user}` : "Session unavailable");
        if (data.authenticated) {
          loadReward();
        }
      })
      .catch(() => {
        setStatus("Session unavailable");
        setRewardText("Reward unavailable");
      });
  }, []);

  function handlePwnOpen() {
    if (!pwnKey.trim()) {
      setPwnHint("Key is required.");
      return;
    }

    const url = `./pwn?key=${encodeURIComponent(pwnKey.trim())}`;
    setPwnHint("Opening raw pwn session.");
    window.open(url, "_blank", "noopener,noreferrer");
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-night text-white antialiased">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_12%,rgba(139,243,255,0.20),transparent_26%),radial-gradient(circle_at_78%_20%,rgba(94,234,212,0.12),transparent_24%),linear-gradient(135deg,#04060f_0%,#07101f_44%,#03050b_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.9)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.9)_1px,transparent_1px)] bg-[size:72px_72px] opacity-[0.08]" />
        <div className="absolute -left-24 top-20 h-80 w-80 animate-drift rounded-full bg-accent/20 blur-3xl" />
        <div className="absolute right-[-10rem] top-1/4 h-[28rem] w-[28rem] animate-drift rounded-full bg-cyan-300/10 blur-3xl" />
        <div className="noise absolute inset-0" />
      </div>

      <section className="relative flex min-h-screen flex-col px-6 py-6 sm:px-10 lg:px-14">
        <div className="flex items-center justify-between font-mono text-[11px] uppercase tracking-[0.32em] text-mist/55">
          <span>NCTF 2026</span>
          <span>admin workspace</span>
        </div>

        <div className="mt-10 grid flex-1 gap-12 lg:grid-cols-[minmax(320px,460px)_1fr] lg:items-end">
          <div className={`relative z-10 flex flex-col justify-between ${mounted ? "animate-rise" : "opacity-0"}`}>
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.36em] text-accent/80">
                control plane
              </p>
              <h1 className="mt-5 max-w-md font-display text-[clamp(3rem,7vw,5.8rem)] font-semibold leading-[0.95] tracking-[-0.06em] text-white">
                Unfinished
                <span className="block text-mist">front end</span>
              </h1>
              <p className="mt-6 max-w-sm text-sm leading-7 text-mist/66 sm:text-[15px]">
                Reward, pwn, and downloads now sit behind the authenticated workspace.
              </p>
            </div>

            <div className="mt-12 space-y-8">
              <div className="border-t border-white/12 pt-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-mist/45">
                  Current Login Status
                </p>
                <p className="mt-3 max-w-md text-sm leading-7 text-mist/72 sm:text-[15px]">
                  {status}
                </p>
              </div>

              <div className="border-t border-white/12 pt-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-mist/45">
                  File Download
                </p>
                <div className="mt-4 border-b border-white/18 transition-colors focus-within:border-accent/80">
                  <input
                    type="text"
                    value={downloadFile}
                    onChange={(event) => setDownloadFile(event.target.value)}
                    placeholder="Enter file name"
                    className="h-14 w-full bg-transparent font-display text-lg tracking-[-0.03em] text-white outline-none placeholder:text-mist/30"
                  />
                </div>
                <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center">
                  <button
                    type="button"
                    onClick={() => {
                      if (!downloadFile.trim()) {
                        setDownloadHint("File name is required.");
                        return;
                      }
                      setDownloadHint(`Opening download for ${downloadFile.trim()}.`);
                      window.open(`./download?file=${encodeURIComponent(downloadFile.trim())}`, "_blank", "noopener,noreferrer");
                    }}
                    className="inline-flex h-14 items-center justify-center rounded-full border border-white/14 px-8 font-display text-sm tracking-[0.22em] text-mist transition duration-300 hover:border-accent/60 hover:text-accent"
                  >
                    OPEN DOWNLOAD
                  </button>
                </div>
                <p className="mt-4 text-sm leading-7 text-mist/58">{downloadHint}</p>
              </div>
            </div>
          </div>

          <div className={`relative grid gap-10 pb-4 ${mounted ? "animate-rise [animation-delay:180ms]" : "opacity-0"} lg:grid-cols-2`}>
            <section className="border border-white/10 bg-white/[0.03] p-7 backdrop-blur-sm">
              <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-accent/75">
                Reward
              </p>
              <h2 className="mt-4 text-center font-display text-3xl tracking-[-0.05em] text-white">
                A little reward
              </h2>
              <div className="mt-8 flex min-h-[20rem] flex-col justify-between rounded-[28px] border border-accent/18 bg-night/70 px-6 py-8 shadow-soft">
                <div className="text-center">
                  <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-mist/42">
                  PIE Address
                  </p>
                  <p className="mt-4 break-all font-display text-xl tracking-[-0.04em] text-accent sm:text-2xl">
                    {rewardText}
                  </p>
                </div>
                <div className="mt-8 flex justify-center">
                  <button
                    type="button"
                    onClick={loadReward}
                    className="inline-flex h-14 items-center justify-center rounded-full border border-accent/40 bg-accent/12 px-8 font-display text-sm font-medium tracking-[0.22em] text-accent transition duration-300 hover:border-accent hover:bg-accent hover:text-night"
                  >
                    Trigger Reward
                  </button>
                </div>
              </div>
            </section>

            <section className="border border-white/10 bg-white/[0.03] p-7 backdrop-blur-sm">
              <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-accent/75">
                Pwn
              </p>
              <h2 className="mt-4 font-display text-3xl tracking-[-0.05em] text-white">
                Enter raw loop
              </h2>
              <p className="mt-3 max-w-sm text-sm leading-7 text-mist/62">
                Submit the current key, then continue in the /pwn loop.
              </p>
              <div className="mt-8 border-b border-white/18 transition-colors focus-within:border-accent/80">
                <input
                  type="text"
                  value={pwnKey}
                  onChange={(event) => setPwnKey(event.target.value)}
                  placeholder="Enter pwn key"
                  className="h-14 w-full bg-transparent font-display text-lg tracking-[-0.03em] text-white outline-none placeholder:text-mist/30"
                />
              </div>
              <div className="mt-8 border-t border-white/10 pt-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-mist/42">
                  Status
                </p>
                <p className="mt-3 text-sm leading-7 text-mist/72">{pwnHint}</p>
              </div>
            </section>

            <section className="border-t border-white/12 pt-5 lg:col-span-2">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div></div>
                <button
                  type="button"
                  onClick={handlePwnOpen}
                  className="inline-flex h-12 items-center justify-center rounded-full border border-accent/40 bg-accent/12 px-6 font-mono text-[11px] uppercase tracking-[0.24em] text-accent transition duration-300 hover:border-accent hover:bg-accent hover:text-night"
                >
                  Send
                </button>
              </div>
            </section>
          </div>
        </div>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<AdminApp />);
