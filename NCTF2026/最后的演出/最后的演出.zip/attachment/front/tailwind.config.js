module.exports = {
  content: ["./index.html", "./admin.html", "./app.jsx", "./admin.jsx"],
  theme: {
    extend: {
      fontFamily: {
        display: ["Aptos", "\"Segoe UI\"", "\"PingFang SC\"", "\"Microsoft YaHei\"", "sans-serif"],
        mono: ["Consolas", "\"SFMono-Regular\"", "\"Liberation Mono\"", "monospace"]
      },
      colors: {
        night: "#050816",
        mist: "#c7d2fe",
        steel: "#8b95b3",
        line: "rgba(199, 210, 254, 0.14)",
        panel: "rgba(8, 12, 26, 0.58)",
        accent: "#8bf3ff",
        accentSoft: "#5eead4",
        danger: "#fda4af"
      },
      boxShadow: {
        halo: "0 0 120px rgba(139, 243, 255, 0.12)",
        soft: "0 30px 80px rgba(0, 0, 0, 0.35)"
      },
      keyframes: {
        drift: {
          "0%, 100%": { transform: "translate3d(0, 0, 0) scale(1)" },
          "50%": { transform: "translate3d(0, -18px, 0) scale(1.04)" }
        },
        rise: {
          "0%": { opacity: "0", transform: "translate3d(0, 18px, 0)" },
          "100%": { opacity: "1", transform: "translate3d(0, 0, 0)" }
        },
        pulseLine: {
          "0%, 100%": { opacity: "0.18" },
          "50%": { opacity: "0.42" }
        }
      },
      animation: {
        drift: "drift 8s ease-in-out infinite",
        rise: "rise 900ms cubic-bezier(.2,.8,.2,1) both",
        pulseLine: "pulseLine 3.6s ease-in-out infinite"
      }
    }
  },
  plugins: []
};
