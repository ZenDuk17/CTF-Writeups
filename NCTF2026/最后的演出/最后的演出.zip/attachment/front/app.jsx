import React, { startTransition, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";

function App() {
  const [mounted, setMounted] = useState(false);
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState({
    type: "idle",
    text: "Use admin and submit the current round password."
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  async function handleSubmit(event) {
    event.preventDefault();

    if (username.trim() !== "admin") {
      setStatus({ type: "error", text: "Username must be admin." });
      return;
    }

    if (!password) {
      setStatus({ type: "error", text: "Enter the password." });
      return;
    }

    setLoading(true);
    startTransition(() => {
      setStatus({ type: "pending", text: "Verifying current round password..." });
    });

    try {
      const response = await fetch("./login", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `username=${encodeURIComponent(username.trim())}&password=${encodeURIComponent(password)}`
      });

      const text = await response.text();
      startTransition(() => {
        setStatus({
          type: response.ok ? "success" : "error",
          text
        });
      });

      if (response.ok) {
        window.setTimeout(() => {
          window.location.href = "./admin";
        }, 720);
      }
    } catch (error) {
      setStatus({ type: "error", text: `Request failed: ${error.message}` });
    } finally {
      setLoading(false);
    }
  }

  const statusTone =
    status.type === "success"
      ? "border-accent/30 text-accent"
      : status.type === "error"
        ? "border-danger/35 text-danger"
        : "border-white/10 text-mist/72";

  return (
    <main className="relative min-h-screen overflow-hidden bg-night text-white antialiased">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_18%,rgba(139,243,255,0.22),transparent_28%),radial-gradient(circle_at_80%_28%,rgba(94,234,212,0.14),transparent_24%),linear-gradient(135deg,#04060f_0%,#07101f_44%,#03050b_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.9)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.9)_1px,transparent_1px)] bg-[size:72px_72px] opacity-[0.08]" />
        <div className="absolute -left-24 top-16 h-72 w-72 animate-drift rounded-full bg-accent/20 blur-3xl" />
        <div className="absolute right-[-8rem] top-1/3 h-96 w-96 animate-drift rounded-full bg-cyan-300/10 blur-3xl" />
        <div className="noise absolute inset-0" />
        <div className="absolute inset-y-0 left-[52%] hidden w-px bg-white/10 lg:block" />
      </div>

      <section className="relative flex min-h-screen flex-col justify-between px-6 py-6 sm:px-10 lg:px-14">
        <div className="flex items-center justify-between font-mono text-[11px] uppercase tracking-[0.32em] text-mist/55">
          <span>NCTF 2026</span>
          <span>admin access</span>
        </div>

        <div className="grid min-h-[calc(100svh-5rem)] items-center gap-12 lg:grid-cols-[minmax(320px,440px)_1fr]">
          <div className={`relative z-10 max-w-xl ${mounted ? "animate-rise" : "opacity-0"}`}>
            <p className="font-mono text-[11px] uppercase tracking-[0.36em] text-accent/80">
              secure gateway
            </p>
            <h1 className="mt-5 max-w-md font-display text-[clamp(3rem,7vw,5.8rem)] font-semibold leading-[0.95] tracking-[-0.06em] text-white">
              Enter the only
              <span className="block text-mist">admin session</span>
            </h1>
            <p className="mt-6 max-w-sm text-sm leading-7 text-mist/66 sm:text-[15px]">
              The interface only submits. Real verification happens after
              <span className="font-mono text-accent/90"> POST /login </span>
              returns.
            </p>

            <form className="mt-10 space-y-7" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <label className="font-mono text-[11px] uppercase tracking-[0.28em] text-mist/55" htmlFor="username">
                  Username
                </label>
                <div className="border-b border-white/18 transition-colors focus-within:border-accent/80">
                  <input
                    id="username"
                    name="username"
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(event) => setUsername(event.target.value)}
                    className="h-14 w-full bg-transparent font-display text-lg tracking-[-0.03em] text-white outline-none placeholder:text-mist/30"
                    placeholder="admin"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="font-mono text-[11px] uppercase tracking-[0.28em] text-mist/55" htmlFor="password">
                  Password
                </label>
                <div className="border-b border-white/18 transition-colors focus-within:border-accent/80">
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    className="h-14 w-full bg-transparent font-display text-lg tracking-[0.04em] text-white outline-none placeholder:text-mist/30"
                    placeholder="Enter current round password"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                <button
                  type="submit"
                  disabled={loading}
                  className="group inline-flex h-14 items-center justify-center rounded-full border border-accent/40 bg-accent/12 px-8 font-display text-sm font-medium tracking-[0.22em] text-accent transition duration-300 hover:border-accent hover:bg-accent hover:text-night disabled:cursor-not-allowed disabled:opacity-55"
                >
                  <span className="transition duration-300 group-hover:-translate-y-[1px]">
                    {loading ? "VERIFYING" : "LOGIN"}
                  </span>
                </button>
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-mist/40">
                  user fixed as admin
                </p>
              </div>

              <div className={`min-h-[104px] border-t pt-5 ${statusTone}`}>
                <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-mist/45">
                  Login Result
                </p>
                <div className="mt-3 flex items-start gap-3">
                  <div className="mt-2 h-px w-12 animate-pulseLine bg-current" />
                  <p className="max-w-md text-sm leading-7 sm:text-[15px]">{status.text}</p>
                </div>
              </div>
            </form>
          </div>

          <div className={`relative hidden min-h-[70vh] items-center justify-center lg:flex ${mounted ? "animate-rise [animation-delay:180ms]" : "opacity-0"}`}>
            <div className="absolute inset-x-8 top-1/2 h-px -translate-y-1/2 bg-white/10" />
            <div className="absolute right-[12%] top-[18%] h-40 w-40 rounded-full border border-accent/20" />
            <div className="absolute right-[16%] top-[22%] h-24 w-24 rounded-full border border-white/10" />

            <div className="relative w-full max-w-[760px]">
              <div className="absolute left-10 top-0 font-mono text-[11px] uppercase tracking-[0.38em] text-mist/35">
                srand(/dev/random)
              </div>
              <div className="absolute right-10 top-20 font-mono text-[11px] uppercase tracking-[0.38em] text-mist/30">
                rand() - next session
              </div>

              <div className="select-none font-display text-[clamp(8rem,18vw,16rem)] font-semibold leading-none tracking-[-0.12em] text-white/[0.08]">
                rand()
              </div>

              <div className="absolute left-12 top-[26%] max-w-[16rem] border-t border-white/12 pt-5 text-sm leading-7 text-mist/55">
                Admin access does not sit in plain sight. The valid session only appears after the intended chain succeeds.
              </div>

              <div className="absolute bottom-[10%] right-10 w-[20rem] border-t border-accent/20 pt-5 text-right">
                <p className="font-mono text-[11px] uppercase tracking-[0.34em] text-accent/70">
                  session gate
                </p>
                <p className="mt-3 text-sm leading-7 text-mist/58">
                  One action only. Input, submit, receive, then move to /admin.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
