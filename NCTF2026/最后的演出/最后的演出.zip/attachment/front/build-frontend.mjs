import { build } from "esbuild";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";

const execFileAsync = promisify(execFile);
const root = process.cwd();

async function buildFrontend() {
  await build({
    entryPoints: {
      app: path.join(root, "app.jsx"),
      admin: path.join(root, "admin.jsx")
    },
    bundle: true,
    minify: true,
    format: "iife",
    platform: "browser",
    target: ["es2019"],
    outdir: root,
    entryNames: "[name]"
  });

  await execFileAsync(
    process.execPath,
    [
      path.join(root, "node_modules", "tailwindcss", "lib", "cli.js"),
      "-c",
      path.join(root, "tailwind.config.js"),
      "-i",
      path.join(root, "tailwind.css"),
      "-o",
      path.join(root, "style.css"),
      "--minify"
    ]
  );
}

buildFrontend().catch((error) => {
  console.error(error);
  process.exit(1);
});
